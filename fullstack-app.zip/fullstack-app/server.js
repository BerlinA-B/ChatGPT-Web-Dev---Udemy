const express = require('express');
const app = express();
const mongoose = require('mongoose');
const cors = require('cors');

app.use(cors());
app.use(express.json());

const uri = "mongodb+srv://1234567890:1234567890@cluster0.tjb3y.mongodb.net/?retryWrites=true&w=majority";

async function connect(){
    try {
        await mongoose.connect( uri, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log('Successfully connected to MongoDB Atlas!');
    } catch (error) {
        console.error('Error connecting to MongoDB Atlas: ' + error);
  
    }
}
connect();

const userSchema = new mongoose.Schema({
    username: String,
    password: String
  });
  
const User = mongoose.model('User', userSchema);

const newUser = new User({
    username: 'John Doe',
    password: '12345'
  });
  
  newUser.save((error) => {
    if (error) throw error;
    console.log('New user has been saved to the database.');
  });

app.get('/', (req, res) => {
  res.send('Welcome to my game app!');
});

app.post('/', (req,res) => {
    const {username, password} = req.body;
    const user = new User({
        username,
        password
    });
    user.save((error) => {
        if (error){
            res.status(500).send(error);
        } else{
            res.send('User saved to database');
        }
    });
})

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});

